# Dapp
Develop a Web3j DAPP that interacts with local GETH client
